//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by LAB1_PWSG_OCENIANE.rc
//
#define IDC_MYICON                      2
#define IDD_LAB1PWSGOCENIANE_DIALOG     102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_LAB1PWSGOCENIANE            107
#define IDI_SMALL                       108
#define IDC_LAB1PWSGOCENIANE            109
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDB_BITMAP1                     130
#define ID_8                            32771
#define ID_4                            32773
#define ID_Menu                         32774
#define ID_64                           32775
#define ID_Menu32776                    32776
#define ID_2048                         32777
#define ID_16                           32778
#define IDM_NEW_GAME                    32779
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
