// LAB1_PWSG_OCENIANE.cpp : Defines the entry point for the application.
//

#include "framework.h"
#include "LAB1_PWSG_OCENIANE.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst; // current instance
WCHAR szTitle[MAX_LOADSTRING]; // The title bar text
WCHAR szWindowClass[MAX_LOADSTRING]; // the main window class name
WCHAR childClass[] = L"child";
WCHAR cloneClass[] = L"clone";
int centerX;
int centerY;
HWND hWnd2;
HWND hWnd1;
int pos1x = 0;
int pos1y = 0;
int pos2x = 0;
int pos2y = 0;

// Forward declarations of functions included in this code module:
ATOM MyRegisterClass(HINSTANCE hInstance);
BOOL InitInstance(HINSTANCE, int);
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc2(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WndProc3(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                      _In_opt_ HINSTANCE hPrevInstance,
                      _In_ LPWSTR lpCmdLine,
                      _In_ int nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// TODO: Place code here.

	// Initialize global strings
	RECT rc;
	SystemParametersInfo(SPI_GETWORKAREA, 0, &rc, 0);
	centerX = (rc.left + rc.right + 1) / 2;
	centerY = (rc.top + rc.bottom + 1) / 2;
	LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadStringW(hInstance, IDC_LAB1PWSGOCENIANE, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow))
	{
		return FALSE;
	}

	HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_LAB1PWSGOCENIANE));

	MSG msg;

	// Main message loop:
	while (GetMessage(&msg, nullptr, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int)msg.wParam;
}


//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEXW wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON1));
	wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
	wcex.hbrBackground = CreateSolidBrush(RGB(250, 247, 238));
	wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_LAB1PWSGOCENIANE);
	wcex.lpszClassName = szWindowClass;
	wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_ICON1));

	WNDCLASSEXW wcex2;

	wcex2.cbSize = sizeof(WNDCLASSEX);

	wcex2.style = CS_HREDRAW | CS_VREDRAW;
	wcex2.lpfnWndProc = WndProc2;
	wcex2.cbClsExtra = 0;
	wcex2.cbWndExtra = 0;
	wcex2.hInstance = hInstance;
	wcex2.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON1));
	wcex2.hCursor = LoadCursor(hInstance, MAKEINTRESOURCE(IDC_MYICON));
	wcex2.hbrBackground = CreateSolidBrush(RGB(204, 192, 174));
	wcex2.lpszMenuName = MAKEINTRESOURCEW(IDC_LAB1PWSGOCENIANE);
	wcex2.lpszClassName = L"child";
	wcex2.hIconSm = LoadIcon(wcex2.hInstance, MAKEINTRESOURCE(IDI_ICON1));
	RegisterClassExW(&wcex2);
	WNDCLASSEXW wcex3;

	wcex3.cbSize = sizeof(WNDCLASSEX);

	wcex3.style = CS_HREDRAW | CS_VREDRAW;
	wcex3.lpfnWndProc = WndProc3;
	wcex3.cbClsExtra = 0;
	wcex3.cbWndExtra = 0;
	wcex3.hInstance = hInstance;
	wcex3.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON1));
	wcex3.hCursor = LoadCursor(nullptr, IDC_ARROW);
	wcex3.hbrBackground = CreateSolidBrush(RGB(250, 247, 238));
	wcex3.lpszMenuName = MAKEINTRESOURCEW(IDC_LAB1PWSGOCENIANE);
	wcex3.lpszClassName = cloneClass;
	wcex3.hIconSm = LoadIcon(wcex3.hInstance, MAKEINTRESOURCE(IDI_ICON1));
	RegisterClassExW(&wcex3);

	return RegisterClassExW(&wcex);
}


//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	hInst = hInstance; // Store instance handle in our global variable

	hWnd1 = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
	                          CW_USEDEFAULT, 0, 310, 350, nullptr, nullptr, hInstance, nullptr);

	if (!hWnd1)
	{
		return FALSE;
	}
	SetWindowLong(hWnd1, GWL_STYLE,
	              GetWindowLong(hWnd1, GWL_STYLE) & ~WS_SIZEBOX);

	hWnd2 = CreateWindow(L"clone", szTitle, WS_OVERLAPPED, CW_USEDEFAULT, 0, 310, 350, hWnd1, nullptr, hInstance,
	                     nullptr);
	SetWindowLong(hWnd2, GWL_STYLE,
	              GetWindowLong(hWnd2, GWL_STYLE) & ~WS_SIZEBOX);
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			HWND child = CreateWindow(L"child", szTitle, WS_CHILD, 10*(i+1) + i*60, 10 * (j + 1) + j * 60, 60, 60, hWnd1,
			                          nullptr, hInstance, nullptr);
			SetMenu(child, NULL);
			ShowWindow(child, nCmdShow);
			child = CreateWindow(L"child", szTitle, WS_CHILD, 10 * (i + 1) + i * 60, 10 * (j + 1) + j * 60, 60, 60,
			                     hWnd2,
			                     nullptr, hInstance, nullptr);
			SetMenu(child, NULL);
			ShowWindow(child, nCmdShow);
		}
	}
	// SetWindowPos(hWnd, 0,600, 600, 0,0, SWP_NOSIZE);
	ShowWindow(hWnd2, nCmdShow);
	UpdateWindow(hWnd2);
	ShowWindow(hWnd2, nCmdShow);
	ShowWindow(hWnd1, nCmdShow);
	UpdateWindow(hWnd1);

	return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE: Processes messages for the main window.
//
//  WM_COMMAND  - process the application menu
//  WM_PAINT    - Paint the main window
//  WM_DESTROY  - post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_COMMAND:
		{
			int wmId = LOWORD(wParam);
			// Parse the menu selections:
			switch (wmId)
			{
			case IDM_ABOUT:
				DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
				break;
			case IDM_EXIT:
				DestroyWindow(hWnd);
				break;
			default:
				return DefWindowProc(hWnd, message, wParam, lParam);
			}
		}
		break;
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			// TODO: Add any drawing code that uses hdc here...
			EndPaint(hWnd, &ps);
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_MOVING:
		{
			RECT* rc = (RECT*)lParam;
			int cx = rc->right - (rc->right - rc->left);
			int cy = rc->top - (rc->bottom - rc->top);
			int c2x = centerX - cx;
			int c2y = centerY - cy;
			pos2x = c2x + (rc->right - rc->left) + (rc->right - rc->left);
			pos2y = c2y - (rc->bottom - rc->top) + (rc->bottom - rc->top);
			SetWindowPos(hWnd2, 0, c2x + (rc->right - rc->left), c2y - (rc->bottom - rc->top), 0, 0, SWP_NOSIZE);
			if (abs(pos1x - pos2x) < (rc->right - rc->left)/2 || abs(pos1y - pos2y) < (rc->bottom - rc->top)/2)
			{
				SetWindowLong(hWnd2, GWL_EXSTYLE,
					GetWindowLong(hWnd2, GWL_EXSTYLE) | WS_EX_LAYERED);
				// Make this window 50% alpha
				SetLayeredWindowAttributes(hWnd2, 0, (255 * 50) / 100, LWA_ALPHA);
				// Show this window
				UpdateWindow(hWnd2);
			}
			else
			{
				SetWindowLong(hWnd2, GWL_EXSTYLE,
					GetWindowLong(hWnd2, GWL_EXSTYLE) | WS_EX_LAYERED);
				// Make this window 50% alpha
				SetLayeredWindowAttributes(hWnd2, 0, (255 * 100) / 100, LWA_ALPHA);
				// Show this window
				UpdateWindow(hWnd2);
			}
		}
		break;
	case WM_GETMINMAXINFO:
		{
			MINMAXINFO* info = (MINMAXINFO*)lParam;

			info->ptMaxSize = POINT{310, 350};
		}
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

LRESULT CALLBACK WndProc2(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_COMMAND:
		{
			int wmId = LOWORD(wParam);
			// Parse the menu selections:
			switch (wmId)
			{
			case IDM_ABOUT:
				DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
				break;
			case IDM_EXIT:
				DestroyWindow(hWnd);
				break;
			default:
				return DefWindowProc(hWnd, message, wParam, lParam);
			}
		}
		break;
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			// TODO: Add any drawing code that uses hdc here...
			EndPaint(hWnd, &ps);
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

LRESULT CALLBACK WndProc3(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_COMMAND:
		{
			int wmId = LOWORD(wParam);
			// Parse the menu selections:
			switch (wmId)
			{
			case IDM_ABOUT:
				DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
				break;
			case IDM_EXIT:
				DestroyWindow(hWnd);
				break;
			default:
				return DefWindowProc(hWnd, message, wParam, lParam);
			}
		}
		break;
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			// TODO: Add any drawing code that uses hdc here...
			EndPaint(hWnd, &ps);
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_MOVING:
		{
			RECT* rc = (RECT*)lParam;
			int cx = rc->right - (rc->right - rc->left);
			int cy = rc->top - (rc->bottom - rc->top);
			int c2x = centerX - cx;
			int c2y = centerY - cy;
			pos1x = c2x + (rc->right - rc->left) + (rc->right - rc->left);
			pos1y = c2y - (rc->bottom - rc->top) + (rc->bottom - rc->top);
			SetWindowPos(hWnd1, 0, c2x + (rc->right - rc->left), c2y - (rc->bottom - rc->top), 0, 0, SWP_NOSIZE);
			if(abs(pos1x-pos2x) < (rc->right - rc->left)/2 || abs(pos1y - pos2y) < (rc->bottom - rc->top)/2)
			{
				SetWindowLong(hWnd, GWL_EXSTYLE,
				GetWindowLong(hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
				// Make this window 50% alpha
					SetLayeredWindowAttributes(hWnd, 0, (255 * 50) / 100, LWA_ALPHA);
				// Show this window
				UpdateWindow(hWnd);
			} else
			{
				SetWindowLong(hWnd, GWL_EXSTYLE,
					GetWindowLong(hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
				// Make this window 50% alpha
				SetLayeredWindowAttributes(hWnd, 0, (255 * 100) / 100, LWA_ALPHA);
				// Show this window
				UpdateWindow(hWnd);
			}
		}
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
